# 주차별 종합실습 모범 답안 코드 모음

## 1~2주차 모범 답안 – 회귀 실험 (Diabetes)

```python
import numpy as np
import tensorflow as tf
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
import matplotlib.pyplot as plt

tf.random.set_seed(42)
np.random.seed(42)

data = load_diabetes()
X, y = data.data, data.target

def run_experiment(scaler_cls, hidden_units, name):
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    scaler = scaler_cls()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    model = tf.keras.Sequential()
    model.add(tf.keras.layers.Dense(hidden_units[0], activation='relu', input_shape=(X.shape[1],)))
    for u in hidden_units[1:]:
        model.add(tf.keras.layers.Dense(u, activation='relu'))
    model.add(tf.keras.layers.Dense(1))
    model.compile(optimizer='adam', loss='mse')

    early = tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=20, restore_best_weights=True)
    ckpt = tf.keras.callbacks.ModelCheckpoint(f'best_{name}.keras', save_best_only=True, monitor='val_loss')

    hist = model.fit(
        X_train, y_train,
        epochs=300, batch_size=32,
        validation_split=0.2,
        callbacks=[early, ckpt],
        verbose=0
    )

    y_pred = model.predict(X_test, verbose=0).flatten()
    r2 = r2_score(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    mae = mean_absolute_error(y_test, y_pred)
    print(f"[{name}] R2={r2:.4f}  RMSE={rmse:.4f}  MAE={mae:.4f}")
    return hist, model

# 실험 실행
run_experiment(StandardScaler, [64, 32], "std_64_32")
run_experiment(MinMaxScaler, [64, 32], "minmax_64_32")
run_experiment(StandardScaler, [128, 64, 32], "std_deep")
```

---

## 7일 이진분류 모범 답안 (이미 Notebook에 포함)

`notebooks/07일_이진분류_EarlyStopping.ipynb` 참고

---

## PyTorch MLP 모범 답안

`notebooks/32_35일_PyTorch_MLP.ipynb` 참고

---

## RAG 최소 완전체 모범 구조 (9~10주차)

```python
# 필요 패키지: langchain, langchain-community, chromadb, sentence-transformers
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser

# 1. 로드 & 청킹
loader = TextLoader("sample_doc.txt", encoding="utf-8")
docs = loader.load()
splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=80)
splits = splitter.split_documents(docs)

# 2. 임베딩 + VectorStore
embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2")
vectorstore = Chroma.from_documents(documents=splits, embedding=embeddings, persist_directory="./chroma_db")
retriever = vectorstore.as_retriever(search_kwargs={"k": 4})

# 3. 프롬프트
template = """다음 컨텍스트만을 근거로 질문에 답하세요. 모르는 내용은 '문서에서 찾을 수 없습니다'라고 하세요.
컨텍스트:
{context}

질문: {question}
답변:"""
prompt = ChatPromptTemplate.from_template(template)

# 4. LLM은 OpenAI 호환 또는 로컬 모델로 교체
# from langchain_openai import ChatOpenAI
# llm = ChatOpenAI(base_url="http://localhost:8000/v1", api_key="EMPTY", model="EMPTY")

# chain = (
#     {"context": retriever, "question": RunnablePassthrough()}
#     | prompt
#     | llm
#     | StrOutputParser()
# )
# print(chain.invoke("질문 내용"))
```

---

## RNGD + LangGraph 연동 모범 패턴

```python
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, END
from typing import TypedDict, Annotated
import operator

# RNGD 서버가 실행 중이어야 함
llm = ChatOpenAI(
    base_url="http://localhost:8000/v1",
    api_key="EMPTY",
    model="EMPTY",
    temperature=0.2
)

class AgentState(TypedDict):
    messages: Annotated[list, operator.add]
    next: str

def call_model(state: AgentState):
    response = llm.invoke(state["messages"])
    return {"messages": [response]}

# 간단한 그래프 예시
workflow = StateGraph(AgentState)
workflow.add_node("agent", call_model)
workflow.set_entry_point("agent")
workflow.add_edge("agent", END)
app = workflow.compile()

# result = app.invoke({"messages": [("user", "RNGD의 장점은?")]})
```

---

이 모범 답안을 기반으로 각 주차 과제를 채점하거나 학습자 참고용으로 배포하시면 됩니다.
필요 시 더 많은 일자별 모범 코드를 추가 요청해 주세요.
