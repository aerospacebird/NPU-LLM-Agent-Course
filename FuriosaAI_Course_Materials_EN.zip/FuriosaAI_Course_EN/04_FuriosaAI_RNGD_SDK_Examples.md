# FuriosaAI RNGD 공식 SDK 최신 코드 예제 모음
**기준**: Furiosa SDK 2026.3.0 / developer.furiosa.ai (2026년 기준)

공식 문서: https://developer.furiosa.ai/latest/en/  
Hugging Face 모델: https://huggingface.co/furiosa-ai  
GitHub: https://github.com/furiosa-ai

---

## 1. 환경 확인 및 기본 설치

```bash
# Python 패키지
pip install furiosa-llm openai

# 또는 전체 SDK
pip install furiosa-sdk
```

```python
# 버전 확인 예시
import furiosa_llm
print(furiosa_llm.__version__)  # 실제 설치된 버전 확인
```

---

## 2. OpenAI 호환 서버 실행 (가장 중요)

```bash
# 사전 컴파일된 모델 사용 (권장)
furiosa-llm serve furiosa-ai/Llama-3.1-8B-Instruct

# 또는 로컬 artifact 경로
furiosa-llm serve /path/to/your/artifact

# 포트 변경, tool calling 활성화 예시
furiosa-llm serve furiosa-ai/Qwen3-32B-FP8 \
    --host 0.0.0.0 \
    --port 8000 \
    --enable-auto-tool-choice \
    --tool-call-parser hermes
```

서버가 정상 기동되면 `http://localhost:8000` 에서 OpenAI 호환 API를 제공합니다.

---

## 3. 기본 Chat Completion (비스트리밍)

```python
import os
from openai import OpenAI

client = OpenAI(
    base_url=os.getenv("OPENAI_BASE_URL", "http://localhost:8000/v1"),
    api_key=os.getenv("OPENAI_API_KEY", "EMPTY")
)

response = client.chat.completions.create(
    model="EMPTY",  # 서버에 로드된 모델 사용
    messages=[
        {"role": "system", "content": "당신은 FuriosaAI RNGD 전문가입니다."},
        {"role": "user", "content": "RNGD의 Tensor Contraction Processor 아키텍처를 쉽게 설명해 주세요."}
    ],
    temperature=0.7,
    max_tokens=512
)

print(response.choices[0].message.content)
print(f"Usage: {response.usage}")
```

---

## 4. 스트리밍 응답

```python
from openai import OpenAI

client = OpenAI(base_url="http://localhost:8000/v1", api_key="EMPTY")

stream = client.chat.completions.create(
    model="EMPTY",
    messages=[{"role": "user", "content": "NPU 기반 LLM 서빙의 장점을 3가지로 요약해 주세요."}],
    stream=True,
    temperature=0.5
)

for chunk in stream:
    content = chunk.choices[0].delta.content
    if content is not None:
        print(content, end="", flush=True)
print()
```

---

## 5. Async 버전

```python
import asyncio
from openai import AsyncOpenAI

async def main():
    client = AsyncOpenAI(base_url="http://localhost:8000/v1", api_key="EMPTY")
    
    stream = await client.chat.completions.create(
        model="EMPTY",
        messages=[{"role": "user", "content": "안녕하세요"}],
        stream=True
    )
    
    async for chunk in stream:
        if chunk.choices[0].delta.content:
            print(chunk.choices[0].delta.content, end="", flush=True)
    print()

asyncio.run(main())
```

---

## 6. Tool Calling 예제

서버 실행 시 `--enable-auto-tool-choice --tool-call-parser hermes` (또는 llama 등) 옵션 필요.

```python
from openai import OpenAI
import json

client = OpenAI(base_url="http://localhost:8000/v1", api_key="EMPTY")

tools = [
    {
        "type": "function",
        "function": {
            "name": "get_current_weather",
            "description": "특정 도시의 현재 날씨를 가져옵니다",
            "parameters": {
                "type": "object",
                "properties": {
                    "location": {
                        "type": "string",
                        "description": "도시 이름, 예: 서울, 부산"
                    },
                    "unit": {
                        "type": "string",
                        "enum": ["celsius", "fahrenheit"]
                    }
                },
                "required": ["location"]
            }
        }
    }
]

response = client.chat.completions.create(
    model="EMPTY",
    messages=[{"role": "user", "content": "서울 날씨 알려줘"}],
    tools=tools,
    tool_choice="auto"
)

message = response.choices[0].message
print(message)

if message.tool_calls:
    tool_call = message.tool_calls[0]
    print("호출된 함수:", tool_call.function.name)
    print("인자:", tool_call.function.arguments)
```

---

## 7. 모델 준비 개념 (Quantization + Artifact)

실제 하드웨어에서는 다음 흐름을 따릅니다.

1. Hugging Face에서 모델 로드
2. Calibration 데이터로 양자화 (FP8, INT8, SmoothQuant 계열 등)
3. `furiosa-llm build` 또는 ArtifactBuilder로 컴파일
4. 생성된 Artifact를 `furiosa-llm serve`로 서빙

```bash
# 개념적 예시 (실제 옵션은 문서 확인)
furiosa-llm build <model_id_or_path> <output_artifact_path> \
    --quantization fp8 \
    --tensor-parallel-size 1
```

사전 컴파일된 모델은 Hugging Face `furiosa-ai` 조직에서 바로 사용 가능합니다.

---

## 8. 성능 측정 시 주요 지표

- **TTFT** (Time To First Token)
- **TPOT** (Time Per Output Token)
- **Throughput** (tokens / second)
- **Memory usage**
- Continuous Batching 적용 전후 비교
- 정밀도별 (BF16 / FP8 / INT8) 비교

`furiosa-mlperf` 도구를 사용하면 표준 벤치마크를 쉽게 실행할 수 있습니다.

---

## 9. Docker로 실행하는 방법 (참고)

```bash
docker pull furiosaai/furiosa-llm:latest

docker run -it --rm \
  --device /dev/rngd:/dev/rngd \
  --security-opt seccomp=unconfined \
  -p 8000:8000 \
  -v $HOME/.cache/huggingface:/root/.cache/huggingface \
  furiosaai/furiosa-llm:latest \
  serve furiosa-ai/Qwen2.5-0.5B-Instruct
```

---

## 10. LangGraph / RAG Agent와 연동하는 방법

OpenAI 호환이므로 LangChain / LangGraph에서 다음과 같이 사용합니다.

```python
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(
    base_url="http://localhost:8000/v1",
    api_key="EMPTY",
    model="EMPTY",
    temperature=0.3
)

# 이후 LangGraph 노드에서 그대로 사용 가능
```

---

**참고 자료**
- Quick Start: https://developer.furiosa.ai/latest/en/get_started/furiosa_llm.html
- OpenAI Server: https://developer.furiosa.ai/latest/en/furiosa_llm/furiosa-llm-serve.html
- Model Preparation: https://developer.furiosa.ai/latest/en/furiosa_llm/model-preparation.html
- RNGD 스펙: https://developer.furiosa.ai/latest/en/overview/rngd.html

이 예제들을 61~80일 실습에 바로 활용하시면 됩니다.  
실제 RNGD 하드웨어가 있는 환경에서 테스트해 보시기 바랍니다.