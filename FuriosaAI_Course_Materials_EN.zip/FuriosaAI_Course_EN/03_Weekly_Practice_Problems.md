# 주차별 종합실습 문제 세트
## NPU 기반 LLM Agent 서비스 구축 전문가 양성 과정

---

## 1~2주차 종합실습 (1~10일)

### 문제 1. 회귀 모델 완전 비교 실험
**목표**: Diabetes 또는 California Housing 데이터를 사용하여 아래 조건을 모두 만족하는 실험 노트북을 작성하시오.

1. StandardScaler / MinMaxScaler 적용 전후 성능 비교
2. 은닉층 구조 3가지 이상 비교 (예: [32], [64,32], [128,64,32])
3. EarlyStopping + ModelCheckpoint 적용
4. R², RMSE, MAE 모두 출력
5. 학습 곡선 시각화
6. 최종 모델을 `.keras`로 저장하고 다시 불러와 추론

**제출물**: `01_regression_experiment.ipynb`

### 문제 2. 이진분류 + 다중분류 통합
- Breast Cancer (이진) + Iris/Wine (다중) 데이터 사용
- 동일한 전처리 파이프라인 적용
- 혼동행렬 + classification_report 출력
- Dropout + EarlyStopping 적용

---

## 3~4주차 종합실습 (11~20일)

### 문제 1. 하이퍼파라미터 튜닝 대전
- XGBoost + GridSearchCV / RandomizedSearchCV / Bayesian Optimization 비교
- 동일 데이터셋에서 최종 성능과 소요 시간 비교표 작성

### 문제 2. 전이학습 실험
- VGG16 (include_top=False) + GlobalAveragePooling
- CIFAR-10 또는 자체 이미지 데이터
- 전체 동결 vs 일부 동결 vs 전체 학습 성능 비교

---

## 5~6주차 종합실습 (21~30일)

### 문제
1. TensorFlow 1.x 스타일(placeholder + session)로 선형회귀 및 XOR 문제 해결
2. 동일한 모델을 TensorFlow 2.x Eager 모드로 재구현
3. MNIST DNN + 간단한 CNN 구현 후 정확도 비교

---

## 7~8주차 종합실습 (31~40일)

### 문제 1. PyTorch 완전 정복
- Dataset / DataLoader를 직접 구현
- MNIST, FashionMNIST, CIFAR10에 대해 DNN과 CNN 성능 비교
- LSTM으로 시계열 예측 (Netflix 유사 데이터 또는 공개 시계열)

### 문제 2. AutoEncoder
- 노이즈 제거 AutoEncoder 구현
- PCA와 복원 성능 비교
- Convolutional AutoEncoder까지 확장

---

## 9~10주차 종합실습 (41~50일)

### 최종 RAG 프로젝트
1. 문서 수집 → 청킹 전략 비교 (고정 크기 vs 의미 단위)
2. Chroma vs FAISS 성능/품질 비교
3. Hybrid Search + Reranking 적용
4. End-to-End 문서 기반 질의응답 서비스 프로토타입 구현
5. 간단한 웹 UI 또는 Streamlit/Gradio로 데모

**제출물**: `09_RAG_End2End_프로젝트`

---

## 11~12주차 종합실습 (51~60일)

### Agentic 시스템 구축
1. LangGraph로 Supervisor 패턴 멀티에이전트 구현
2. Tool-Calling 노드 추가
3. Corrective RAG 또는 Self-RAG 적용
4. RAGAS로 평가 리포트 작성
5. 최종 프로젝트 구조 설계 문서 + 발표 자료

---

## 실전통합프로젝트 (61~80일)

### 필수 과제
1. **RNGD 환경 구축 및 검증**
   - 디바이스 인식, SDK 버전 확인, 샘플 모델 실행

2. **모델 준비 및 추론**
   - Hugging Face 모델 또는 자체 모델을 Artifact로 변환
   - 단일 요청 추론 파이프라인 구현

3. **성능 최적화**
   - 정밀도(FP32/BF16/FP8/INT8) 비교
   - batch size, 입력 길이, Continuous Batching 실험
   - latency / throughput / 메모리 측정 및 리포트

4. **서빙 및 Agent 연동**
   - OpenAI 호환 API 서버 구축
   - LangGraph Agent를 RNGD 서버에 연결
   - 오류 처리 및 모니터링 구현

5. **최종 데모데이**
   - “NPU 기반 LLM Agent 서비스” 시연
   - 성능 비교표 (CPU/GPU/NPU)
   - 발표 및 질의응답

**평가 기준**: 기능 완성도, 성능 최적화 수준, 코드 품질, 발표력

---

이 문제 세트를 각 주차 마지막 날에 진행하시면 됩니다.  
필요 시 개별 문제의 모범 답안 코드도 제공 가능합니다.